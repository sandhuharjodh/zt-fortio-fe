export default function AuthPage() {
    return <div>Auth Page</div>;
  }
  